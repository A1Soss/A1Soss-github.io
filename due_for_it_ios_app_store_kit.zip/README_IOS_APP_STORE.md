# DueForIt — iPhone App Store (iOS) Upload Guide

Because Apple requires all iOS App Store submissions to be signed with your personal **Apple Developer Program** certificate and uploaded through **Xcode** or **Transporter**, this kit packages your latest `DueForIt` app into a ready-to-archive **Capacitor iOS project**.

## Included in This Kit
- `www/index.html` — The complete, mobile-optimized **DueForIt** application.
- `www/apple-touch-icon.png` — 180×180 iOS Home Screen icon.
- `AppIcon-1024x1024.png` — Non-transparent 1024×1024 App Store Connect icon required by Apple.
- `capacitor.config.json` — Pre-configured iOS bundle settings (`io.dueforit.sports`, dark status bar, `#050914` background).
- `package.json` — Capacitor 6 iOS dependencies and build scripts.

---

## Option A: Upload to the Apple iOS App Store (via Mac + Xcode)

1. **Prerequisites**:
   - A Mac with **Xcode** installed (from the Mac App Store).
   - **Node.js** (v18+) installed.
   - An active **Apple Developer Program** membership ($99/yr at [developer.apple.com](https://developer.apple.com/)).

2. **Initialize & Open the Xcode Project**:
   Unzip `due_for_it_ios_app_store_kit.zip`, open Terminal in the unzipped folder, and run:
   ```bash
   npm install
   npx cap add ios
   npx cap sync ios
   npx cap open ios
   ```

3. **Set Your App Icon & Signing Team in Xcode**:
   - In Xcode's left sidebar, click **App** → **Signing & Capabilities**, check **Automatically manage signing**, and select your **Apple Developer Team**.
   - Click **Assets.xcassets** → **AppIcon**, and drag `AppIcon-1024x1024.png` into the **1024pt iOS App Store** slot.

4. **Archive & Upload to App Store Connect**:
   - In the top Xcode toolbar, set the destination device to **Any iOS Device (arm64)**.
   - Click **Product → Archive** in the menu bar.
   - When the Archive window opens, click **Distribute App → App Store Connect → Upload**.
   - Log into [App Store Connect](https://appstoreconnect.apple.com/), create a new iOS app with Bundle ID `io.dueforit.sports`, select your uploaded build, add screenshots, and click **Submit for Review**.

---

## Option B: Install on Your iPhone Immediately (No App Store Review Needed)
If you want to use **DueForIt** as a full-screen app on your iPhone right away:
1. Open the hosted app (or `www/index.html`) in **Safari** on your iPhone.
2. Tap the **Share** button (square with upward arrow) at the bottom of Safari.
3. Tap **Add to Home Screen** → **Add**.
4. Launch **DueForIt** from your iPhone Home Screen — it runs in standalone full-screen mode without Safari's address bar.

---

## Uploading from a Windows PC (No Mac Hardware Needed)

### Option A: Cloud Mac Build via Codemagic (Recommended — Free Tier Available)
1. Create a free repository on GitHub from your Windows PC and upload the unzipped contents of this folder (including `codemagic.yaml`).
2. Sign in to **Codemagic** (https://codemagic.io/) in your Windows browser and connect your GitHub repository.
3. In Codemagic, go to **Teams -> Integrations -> Developer Portal** and connect your **App Store Connect API Key** (generated in https://appstoreconnect.apple.com/ under **Users and Access -> Integrations**).
4. Click **Start new build** and select the `ios-capacitor-appstore` workflow defined in `codemagic.yaml`. Codemagic's cloud Mac Mini M2 server will run `npx cap add ios`, sign the `.ipa` with your Apple certificate, and upload the build directly to **App Store Connect** / **TestFlight**.

### Option B: Remote Mac Desktop via MacinCloud from Windows
1. Rent a pay-as-you-go cloud Mac on **MacinCloud** (https://www.macincloud.com/pages/xcode.html) and connect using Windows **Remote Desktop Connection**.
2. Upload this ZIP kit to the cloud Mac, run `npm install && npx cap add ios && npx cap open ios`, sign in with your Apple Developer account in Xcode, and click **Product -> Archive -> Distribute App**.
